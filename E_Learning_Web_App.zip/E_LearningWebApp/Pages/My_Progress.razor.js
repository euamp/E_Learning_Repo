﻿//function setFocus(elementId) {
//    var element = document.getElementById(elementId);
//    if (element) {
//        element.focus();
//    }
//}

//function setFocusToTextBox() {
//    document.getElementById("mytext").focus();
//}