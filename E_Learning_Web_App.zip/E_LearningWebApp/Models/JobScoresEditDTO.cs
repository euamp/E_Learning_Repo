﻿namespace E_LearningWebApp.Models;

public class JobScoresEditDTO
{
    public int Job_Scores_Id { get; set; }
    public int Software_Developer { get; set; }
    public int Web_Developer { get; set; }
    public int Mobile_App_Developer { get; set; }
    public int UI_UX_Designer { get; set; }
    public int Data_Scientist { get; set; }
    public int Machine_Learning_Engineer { get; set; }
    public int Network_Administrator { get; set; }
    public int Cybersecurity_Analyst { get; set; }
    public int Game_Developer { get; set; }
    public int Professors { get; set; }
}
